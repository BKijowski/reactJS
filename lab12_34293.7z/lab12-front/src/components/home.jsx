import React from "react";

const Home = () => {
    return <div className="jumbotron jumbotron-fluid">
        <div className="container">
            <h1 className="display-4">Home</h1>
            <p className="lead">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Atque, aut autem delectus ea
                error esse est eveniet expedita fugiat illo libero magni maxime mollitia optio quasi ratione rem
                repellendus sunt.</p>
        </div>
    </div>;
};

export default Home;
